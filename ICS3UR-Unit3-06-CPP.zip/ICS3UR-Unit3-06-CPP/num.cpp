// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This is another number guessing program

#include <iostream>
#include <random>

int main() {
    std::default_random_engine generator;
    std::uniform_int_distribution<int> distribution(0, 9);
    int integer = distribution(generator);
    int number;

    // input
    std::cout << "Enter a number: ";
    std::cin >> number;
    std::cout << "" << std::endl;

    if (integer == number) {
    std::cout << "Congratulations! You picked the right number!";
    } else if (number < 0) {
        std::cout << "ERROR: INVALID INTEGER";
    } else if (number > 9) {
        std::cout << "ERROR: INVALID INTEGER";
    } else {
        std::cout << "Wrong number! The correct number was:" << std::endl;
        std::cout << integer << std::endl;
    }
}
